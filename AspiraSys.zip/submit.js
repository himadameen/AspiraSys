

// 1st modal
const modalhtml = document.querySelector(".m_38");
const close39 = document.querySelector(".clo-html");
const close390 = document.querySelector(".clos-html");

// 2nd modal
const modal2 = document.querySelector(".m_1");
const close2 = document.querySelector(".clse");
const close22 = document.querySelector("#clse_");

// 3rd modal
const modalJs = document.querySelector(".m_2");
const close3 = document.querySelector(".cle");
const close33 = document.querySelector(".clos");

// 4th modal

const modalA = document.querySelector(".m_3");
const close4 = document.querySelector(".cle-ang");
const close44 = document.querySelector(".clos-ang");

// 5th modal

const modalR = document.querySelector(".m_4");
const close5 = document.querySelector(".clo-react");
const close55 = document.querySelector(".clos-react");


// 6th modal

const modalDot = document.querySelector(".m_5");
const close6 = document.querySelector(".clo-dotnet");
const close66 = document.querySelector(".clos-dotnet");

// 7th modal

const modalspring = document.querySelector(".m_6");
const close7 = document.querySelector(".clo-spring");
const close77 = document.querySelector(".clos-spring");

// 8th modal
const modalnode = document.querySelector(".m_7");
const close8 = document.querySelector(".clo-node");
const close88 = document.querySelector(".clos-node");

// 9th modal
const modalFlutter = document.querySelector(".m_33");
const close34 = document.querySelector(".clo-Flutter");
const close340 = document.querySelector(".clos-Flutter");

// Ruby modal 

const modalRuby = document.querySelector(".m_35");
const close36 = document.querySelector(".clo-Ruby");
const close360 = document.querySelector(".clos-Ruby");


// Dart

const modalDart = document.querySelector(".m_36");
const close37 = document.querySelector(".clo-Dart");
const close370 = document.querySelector(".clos-Dart");



// 10th modal//

const modalKotlin = document.querySelector(".m_9");
const close10 = document.querySelector(".clo-Kotlin");
const close100 = document.querySelector(".clos-Kotlin");

// 11th modal
const modalNative = document.querySelector(".m_10");
const close20 = document.querySelector(".clo-Native");
const close120 = document.querySelector(".clos-Native");

//12th modal
const modalsketch = document.querySelector(".m_11");
const close30 = document.querySelector(".clo-sketch");
const close130 = document.querySelector(".clos-sketch");

//13th modal
const modalAdobe = document.querySelector(".m_12");
const close40 = document.querySelector(".clo-Adobe");
const close140 = document.querySelector(".clos-Adobe");

//14th modal
const modalFigma = document.querySelector(".m_13");
const close50 = document.querySelector(".clo-Figma");
const close150 = document.querySelector(".clos-Figma");


//15th modal
const modalWebflow = document.querySelector(".m_14");
const close60 = document.querySelector(".clo-Webflow");
const close160 = document.querySelector(".clos-Webflow");

//16th modal
const modalBalsamiq = document.querySelector(".m_15");
const close70 = document.querySelector(".clo-Balsamiq");
const close170 = document.querySelector(".clos-Balsamiq");

// 17th modal
const modalC = document.querySelector(".m_18");
const close80 = document.querySelector(".clo-C");
const close180 = document.querySelector(".clos-C");

// 18th modal
const modalCplus = document.querySelector(".m_19");
const close90 = document.querySelector(".clo-Cplus");
const close190 = document.querySelector(".clos-Cplus");

// 19th modal
const modalJava = document.querySelector(".m_21");
const close21 = document.querySelector(".clo-Java");
const close210 = document.querySelector(".clos-Java");

// 20th modal
const modalPyton = document.querySelector(".m_23");
const close23 = document.querySelector(".clo-Pyton");
const close230 = document.querySelector(".clos-Pyton");

// 21st modal
const modalphp = document.querySelector(".m_24");
const close24 = document.querySelector(".clo-php");
const close240 = document.querySelector(".clos-php");

// 22nd modal

const modalDjango = document.querySelector(".m_25");
const close26 = document.querySelector(".clo-Django");
const close260 = document.querySelector(".clos-Django");

//23rd modal
const modalJquery = document.querySelector(".m_26");
const close27 = document.querySelector(".clo-Jquery");
const close270 = document.querySelector(".clos-Jquery");

// 24th modal
const modalHammerkit = document.querySelector(".m_28");
const close29 = document.querySelector(".clo-Hammerkit");
const close290 = document.querySelector(".clos-Hammerkit");

var blur = document.querySelector("#blur");

// programming language //----------------------------------------



function C() {

    modalC.style.display = "block";
    blur.classList.toggle('active');
    modalC.classList.toggle('active');

    close80.addEventListener('click', () => {
        modalC.style.display = "none";
        blur.classList.remove('active');
    })
    close180.addEventListener('click', () => {
        modalC.style.display = "none";
        blur.classList.remove('active');
    })
}



function Cplus() {

    modalCplus.style.display = "block";
    blur.classList.toggle('active');
    modalCplus.classList.toggle('active');

    close90.addEventListener('click', () => {
        modalCplus.style.display = "none";
        blur.classList.remove('active');
    })
    close190.addEventListener('click', () => {
        modalCplus.style.display = "none";
        blur.classList.remove('active');
    })
}

function Java() {

    modalJava.style.display = "block";
    blur.classList.toggle('active');
    modalJava.classList.toggle('active');

    close21.addEventListener('click', () => {
        modalJava.style.display = "none";
        blur.classList.remove('active');
    })
    close210.addEventListener('click', () => {
        modalJava.style.display = "none";
        blur.classList.remove('active');
    })
}


function Pyton() {

    modalPyton.style.display = "block";
    blur.classList.toggle('active');
    modalPyton.classList.toggle('active');

    close23.addEventListener('click', () => {
        modalPyton.style.display = "none";
        blur.classList.remove('active');
    })
    close230.addEventListener('click', () => {
        modalPyton.style.display = "none";
        blur.classList.remove('active');
    })
}

function php() {

    modalphp.style.display = "block";
    blur.classList.toggle('active');
    modalphp.classList.toggle('active');

    close24.addEventListener('click', () => {
        modalphp.style.display = "none";
        blur.classList.remove('active');
    })
    close240.addEventListener('click', () => {
        modalphp.style.display = "none";
        blur.classList.remove('active');
    })
}


//----- Web Development-----------------------------

function html() {

    modalhtml.style.display = "block";
    blur.classList.toggle('active');
    modalhtml.classList.toggle('active');

    close39.addEventListener('click', () => {
        modalhtml.style.display = "none";
        blur.classList.remove('active');
    })
    close390.addEventListener('click', () => {
        modalhtml.style.display = "none";
        blur.classList.remove('active');
    })
}


function css() {
    modal2.style.display = "block";
    blur.classList.toggle('active');
    modal2.classList.toggle('active');

    close2.addEventListener('click', () => {
        modal2.style.display = "none";
        blur.classList.remove('active');
    })

    close22.addEventListener('click', () => {
        modal2.style.display = "none";
        blur.classList.remove('active');
    })

}


function js() {
    modalJs.style.display = "block";
    blur.classList.toggle('active');
    modalJs.classList.toggle('active');

    close3.addEventListener('click', () => {
        modalJs.style.display = "none";
        blur.classList.remove('active');
    })

    close33.addEventListener('click', () => {
        modalJs.style.display = "none";
        blur.classList.remove('active');
    })
}


function angular() {
    modalA.style.display = "block";
    blur.classList.toggle('active');
    modalA.classList.toggle('active');

    close4.addEventListener('click', () => {
        modalA.style.display = "none";
        blur.classList.remove('active');
    })

    close44.addEventListener('click', () => {
        modalA.style.display = "none";
        blur.classList.remove('active');
    })
}


function react() {
    modalR.style.display = "block";
    blur.classList.toggle('active');
    modalR.classList.toggle('active');

    close5.addEventListener('click', () => {
        modalR.style.display = "none";
        blur.classList.remove('active');
    })

    close55.addEventListener('click', () => {
        modalR.style.display = "none";
        blur.classList.remove('active');
    })
}

// --------------------------------------------------------------------//

function dotNet() {

    modalDot.style.display = "block";
    blur.classList.toggle('active');
    modalDot.classList.toggle("active");


    close6.addEventListener('click', () => {
        modalDot.style.display = "none";
        blur.classList.remove('active');
    })

    close66.addEventListener('click', () => {
        modalDot.style.display = "none";
        blur.classList.remove('active');
    })
}

function spring() {

    modalspring.style.display = "block";
    blur.classList.toggle('active');
    modalspring.classList.toggle("active");


    close7.addEventListener('click', () => {
        modalspring.style.display = "none";
        blur.classList.remove('active');
    })

    close77.addEventListener('click', () => {
        modalspring.style.display = "none";
        blur.classList.remove('active');
    })
}

function node() {

    modalnode.style.display = "block";
    blur.classList.toggle('active');
    modalnode.classList.toggle("active");


    close8.addEventListener('click', () => {
        modalnode.style.display = "none";
        blur.classList.remove('active');
    })

    close88.addEventListener('click', () => {
        modalnode.style.display = "none";
        blur.classList.remove('active');
    })
}

function Django() {

    modalDjango.style.display = "block";
    blur.classList.toggle('active');
    modalDjango.classList.toggle("active");


    close26.addEventListener('click', () => {
        modalDjango.style.display = "none";
        blur.classList.remove('active');
    })

    close260.addEventListener('click', () => {
        modalDjango.style.display = "none";
        blur.classList.remove('active');
    })
}

function Jquery() {

    modalJquery.style.display = "block";
    blur.classList.toggle('active');
    modalJquery.classList.toggle("active");


    close27.addEventListener('click', () => {
        modalJquery.style.display = "none";
        blur.classList.remove('active');
    })

    close270.addEventListener('click', () => {
        modalJquery.style.display = "none";
        blur.classList.remove('active');
    })
}

function Hammerkit() {

    modalHammerkit.style.display = "block";
    blur.classList.toggle('active');
    modalHammerkit.classList.toggle("active");


    close29.addEventListener('click', () => {
        modalHammerkit.style.display = "none";
        blur.classList.remove('active');
    })

    close290.addEventListener('click', () => {
        modalHammerkit.style.display = "none";
        blur.classList.remove('active');
    })
}

//----------------------- mobile app -------------------




function Flutter() {

    modalFlutter.style.display = "block";
    blur.classList.toggle('active');
    modalFlutter.classList.toggle("active");


    close34.addEventListener('click', () => {
        modalFlutter.style.display = "none";
        blur.classList.remove('active');
    })

    close340.addEventListener('click', () => {
        modalFlutter.style.display = "none";
        blur.classList.remove('active');
    })
}


function Kotlin() {

    modalKotlin.style.display = "block";
    blur.classList.toggle('active');
    modalKotlin.classList.toggle("active");


    close10.addEventListener('click', () => {
        modalKotlin.style.display = "none";
        blur.classList.remove('active');
    })

    close100.addEventListener('click', () => {
        modalKotlin.style.display = "none";
        blur.classList.remove('active');
    })
}



function Native() {

    modalNative.style.display = "block";
    blur.classList.toggle('active');
    modalNative.classList.toggle("active");


    close20.addEventListener('click', () => {
        modalNative.style.display = "none";
        blur.classList.remove('active');
    })

    close120.addEventListener('click', () => {
        modalNative.style.display = "none";
        blur.classList.remove('active');
    })
}

function Ruby() {

    modalRuby.style.display = "block";
    blur.classList.toggle('active');
    modalRuby.classList.toggle("active");


    close36.addEventListener('click', () => {
        modalRuby.style.display = "none";
        blur.classList.remove('active');
    })

    close360.addEventListener('click', () => {
        modalRuby.style.display = "none";
        blur.classList.remove('active');
    })
}



function Dart() {

    modalDart.style.display = "block";
    blur.classList.toggle('active');
    modalDart.classList.toggle("active");


    close37.addEventListener('click', () => {
        modalDart.style.display = "none";
        blur.classList.remove('active');
    })

    close370.addEventListener('click', () => {
        modalDart.style.display = "none";
        blur.classList.remove('active');
    })
}

//-------------------------------UI/UX Design----------------------------//

function sketch() {

    modalsketch.style.display = "block";
    blur.classList.toggle('active');
    modalsketch.classList.toggle("active");


    close30.addEventListener('click', () => {
        modalsketch.style.display = "none";
        blur.classList.remove('active');
    })

    close130.addEventListener('click', () => {
        modalsketch.style.display = "none";
        blur.classList.remove('active');
    })
}




function Adobe() {

    modalAdobe.style.display = "block";
    blur.classList.toggle('active');
    modalAdobe.classList.toggle("active");


    close40.addEventListener('click', () => {
        modalAdobe.style.display = "none";
        blur.classList.remove('active');
    })

    close140.addEventListener('click', () => {
        modalAdobe.style.display = "none";
        blur.classList.remove('active');
    })
}




function Figma() {

    modalFigma.style.display = "block";
    blur.classList.toggle('active');
    modalFigma.classList.toggle("active");


    close50.addEventListener('click', () => {
        modalFigma.style.display = "none";
        blur.classList.remove('active');
    })

    close150.addEventListener('click', () => {
        modalFigma.style.display = "none";
        blur.classList.remove('active');
    })
}


function Webflow() {

    modalWebflow.style.display = "block";
    blur.classList.toggle('active');
    modalWebflow.classList.toggle("active");


    close60.addEventListener('click', () => {
        modalWebflow.style.display = "none";
        blur.classList.remove('active');
    })

    close160.addEventListener('click', () => {
        modalWebflow.style.display = "none";
        blur.classList.remove('active');
    })
}

function Balsamiq() {

    modalBalsamiq.style.display = "block";
    blur.classList.toggle('active');
    modalBalsamiq.classList.toggle("active");


    close70.addEventListener('click', () => {
        modalBalsamiq.style.display = "none";
        blur.classList.remove('active');
    })

    close170.addEventListener('click', () => {
        modalBalsamiq.style.display = "none";
        blur.classList.remove('active');
    })
}